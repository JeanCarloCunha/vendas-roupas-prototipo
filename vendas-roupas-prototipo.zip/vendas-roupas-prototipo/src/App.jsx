import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import Home from './pages/Home.jsx'
import Login from './pages/Login.jsx'
import Produtos from './pages/Produtos.jsx'
import AdminProdutos from './pages/AdminProdutos.jsx'
import Carrinho from './pages/Carrinho.jsx'
import Checkout from './pages/Checkout.jsx'
import Historico from './pages/Historico.jsx'
import Provador from './pages/Provador.jsx'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/produtos" element={<Produtos />} />
        <Route path="/admin/produtos" element={<AdminProdutos />} />
        <Route path="/carrinho" element={<Carrinho />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/historico" element={<Historico />} />
        <Route path="/provador" element={<Provador />} />
      </Route>
    </Routes>
  )
}
